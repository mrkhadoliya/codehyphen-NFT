export const MenuItems = [
    {
        title:'Home',
        url: '#',
        cName: 'nav-links'
    },
    {
        title:'Explore',
        url: '#',
        cName: 'nav-links'
    },
    {
        title:'Resent Mint',
        url: '#',
        cName: 'nav-links'
    },
    {
        title:'Collocation',
        url: '#',
        cName: 'nav-links'
    },
    // {
    //     title:'Governance',
    //     url: '#',
    //     cName: 'nav-links'
    // }, 
    {
        title:'Conect Wallet',
        url: '#',
        cName: 'nav-links-mobile'
    }, 
]