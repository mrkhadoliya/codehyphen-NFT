const SellersData = [
    {
        imgsrc: 'https://www.designesia.com/themes/gigaland/images/author/author-1.jpg',
        avtrsrc: 'https://www.designesia.com/themes/gigaland/images/author/author-1.jpg',
        title: 'Abstraction',
        links: '#',
        checkicon: 'fas fa-badge-check',
    },
]

export default SellersData;