import React from 'react'

const SellNFTData = [
    {  
        boxheading: 'Set up your wallet',
        title: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.',
        links: '#',
        checkicon: 'fal fa-wallet',
    },
    {  
        boxheading: 'Add your NFT',
        title: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.',
        links: '#',
        checkicon: 'far fa-cloud',
    },
    {  
        boxheading: 'Sell your NFT',
        title: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem.',
        links: '#',
        checkicon: 'fas fa-badge-check',
    } 
     
]

export default SellNFTData;
